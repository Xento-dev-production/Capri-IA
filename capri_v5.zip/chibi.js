// chibi.js : le mode CHIBI secret de Capri (V5)
// Ce fichier se charge APRÈS le script de index.html (une seule ligne à ajouter, déjà faite dans la V5).
//
// Pour l'activer / le désactiver :
//   - clique 5 fois vite sur le mot « CAPRI » dans la fenêtre d'appel,
//   - ou écris /chibi dans le chat et appuie sur Entrée.
// Capri se compresse, puis devient une petite Capri pixel. Le choix est gardé quand on relance l'app.

(function () {
  'use strict';

  // ===== Réglages =====
  const CH_ECHELLE = 0.42;     // taille de la petite Capri en balade (plus grand = plus grosse)
  const SECRET_CLICS = 5;      // nombre de clics rapides sur le nom CAPRI
  const SECRET_TEXTE = '/chibi';
  const DELAI_DODO = 45000;    // sans rien faire pendant ce temps (ms), elle s'endort dans l'appel
  const CHANGE_ATTENTE = 7000; // elle change de pose d'attente toutes les 7 s (appel)
  const CHANGE_FENETRE = 9000; // elle change de pose toutes les 9 s quand elle est assise sur une fenêtre

  // Taille de chaque sprite (largeur, hauteur) : sert à les afficher sans clignoter
  const DIM = {
    idle_lotus: [156, 228], idle_repos: [201, 195], idle_dort: [177, 199],
    idle_assis1: [181, 233], idle_assis2: [164, 223],
    tape_etourdie: [191, 241], tape_coeur: [160, 216], tape_gigote: [200, 200], tape_tire: [178, 187],
    jeu_guette: [212, 225], jeu_balle: [206, 197], jeu_hack: [202, 176], jeu_saut: [180, 224]
  };

  // Poses d'arrêt au sol (les images 6, 8, 9, 10, 11 de la V4) -> sprite chibi
  const SOL = { 6: 'jeu_balle', 8: 'jeu_hack', 9: 'jeu_saut', 10: 'idle_dort', 11: 'tape_gigote' };
  // Quand elle est assise sur une fenêtre : elle change de pose de temps en temps
  const FENETRE = ['idle_assis1', 'idle_repos', 'idle_assis2', 'jeu_guette', 'idle_dort'];
  // Dans la fenêtre d'appel, quand elle attend
  const ATTENTE = ['idle_lotus', 'idle_repos', 'idle_assis1', 'idle_assis2'];

  const url = (n) => 'chibi_' + n + '.png';
  Object.keys(DIM).forEach((n) => { const im = new Image(); im.src = url(n); }); // pré-chargement

  // ===== Style (ajouté ici pour ne pas toucher au CSS de index.html) =====
  const st = document.createElement('style');
  st.textContent =
    'body.chibi #sprite{width:var(--cw)!important;height:var(--ch)!important}' +
    '@keyframes chibiSaute{0%{translate:0 0}50%{translate:0 -7px}}' +
    '#sprite.chibi-saute{animation:chibiSaute .5s step-end infinite}' +
    'body.chibi #portrait{background-color:#2b1d42}' +
    'body.chibi #portrait .layer{background-size:contain;background-repeat:no-repeat;background-position:center bottom}';
  document.head.appendChild(st);

  // ===== État =====
  let chibi = false;
  try { chibi = localStorage.getItem('capriChibi') === '1'; } catch (e) {}
  let derniereV4 = sprite.getAttribute('src') || 'capri7.png'; // la dernière image demandée par la V4
  let courant = '';           // le sprite chibi affiché en balade
  let humeurFen = 0;          // quelle pose sur la fenêtre
  let flagBulle = false;      // vrai quand Capri parle en balade (bulle visible)
  let etatPortrait = 'repos'; // repos | ecoute | reflechit | parle | content | caresse
  let nomPoke = 'tape_coeur';
  let reposIdx = 0;
  let derniereAction = Date.now();
  let finPoke = null, finContent = null;

  // ===== Balade : on intercepte sprite.src =====
  const desc = Object.getOwnPropertyDescriptor(HTMLImageElement.prototype, 'src');
  const lireSrc = () => desc.get.call(sprite);
  const ecrireSrc = (v) => desc.set.call(sprite, v);
  Object.defineProperty(sprite, 'src', {
    configurable: true, enumerable: true,
    get: lireSrc,
    set: (v) => { derniereV4 = String(v); appliquer(); }
  });

  function choisirBalade() {
    const v = derniereV4;
    if (/capri_attrape/.test(v)) return 'tape_etourdie';   // attrapée par le curseur
    if (/capri_tab_lecture/.test(v)) return 'jeu_hack';    // elle lit la tablette
    if (/capri_tab_/.test(v)) return 'jeu_balle';          // elle attrape la tablette
    if (flagBulle) return 'jeu_balle';                     // elle parle
    if (pose === 'assise') return FENETRE[humeurFen % FENETRE.length];
    if (pose === MARCHE) return 'idle_lotus';              // elle flotte et saute en avançant
    return SOL[pose] || 'idle_assis1';
  }

  function appliquer() {
    if (!chibi) {
      courant = '';
      sprite.classList.remove('chibi-saute');
      ecrireSrc(derniereV4);
      return;
    }
    let nom;
    try { nom = choisirBalade(); } catch (e) { nom = 'idle_assis1'; }
    const d = DIM[nom];
    sprite.style.setProperty('--cw', Math.round(d[0] * CH_ECHELLE) + 'px');
    sprite.style.setProperty('--ch', Math.round(d[1] * CH_ECHELLE) + 'px');
    if (courant !== nom) { courant = nom; ecrireSrc(url(nom)); }
    sprite.classList.toggle('chibi-saute', /capri7_/.test(derniereV4) && !flagBulle);
  }

  // La bulle de dialogue visible = Capri est en train de parler
  const bulle = document.getElementById('bulle');
  if (bulle) {
    new MutationObserver(() => {
      const d = bulle.style.display;
      const v = d !== '' && d !== 'none';
      if (v !== flagBulle) { flagBulle = v; if (chibi) appliquer(); }
    }).observe(bulle, { attributes: true, attributeFilter: ['style'] });
  }

  setInterval(() => {
    if (!chibi) return;
    humeurFen++;
    if (pose === 'assise' && !flagBulle) appliquer();
  }, CHANGE_FENETRE);

  // ===== Fenêtre d'appel : le portrait =====
  function majPortrait() {
    if (!chibi) return;
    let nom;
    if (etatPortrait === 'ecoute') nom = 'idle_assis2';
    else if (etatPortrait === 'reflechit') nom = 'tape_etourdie';
    else if (etatPortrait === 'parle') nom = 'jeu_hack';
    else if (etatPortrait === 'content') nom = 'jeu_balle';
    else if (etatPortrait === 'caresse') nom = nomPoke;
    else nom = Date.now() - derniereAction > DELAI_DODO ? 'idle_dort' : ATTENTE[reposIdx % ATTENTE.length];
    portrait.style.setProperty('--img', "url('" + url(nom) + "')");
  }

  setInterval(() => {
    if (chibi && etatPortrait === 'repos') { reposIdx++; majPortrait(); }
  }, CHANGE_ATTENTE);

  // On suit la conversation : qui écoute, qui réfléchit, qui répond
  const parleOrig = window.parle;
  window.parle = function (qui) {
    parleOrig.apply(this, arguments);
    derniereAction = Date.now();
    clearTimeout(finContent);
    if (qui === 'moi') etatPortrait = 'ecoute';
    else if (qui === 'capri') etatPortrait = busy ? 'reflechit' : 'parle';
    else {
      const avait = etatPortrait === 'parle';
      etatPortrait = avait ? 'content' : 'repos';
      if (avait) finContent = setTimeout(() => { if (etatPortrait === 'content') { etatPortrait = 'repos'; majPortrait(); } }, 3500);
    }
    majPortrait();
  };

  // À chaque réponse la V4 change d'image : en mode chibi, elle se met à « écrire » sur son ordi
  const changerOrig = window.changerImage;
  window.changerImage = function () {
    if (chibi) { etatPortrait = 'parle'; majPortrait(); return; }
    changerOrig.apply(this, arguments);
  };

  // Cliquer sur le portrait : câlins et pichenettes (1 clic = cœurs, puis de plus en plus agacée)
  // (on écoute l'appui, pas le clic : la V4 « capture » la souris pour pouvoir déplacer la fenêtre)
  let clics = [];
  portrait.addEventListener('pointerdown', (e) => {
    if (e.button !== 0 || !chibi) return;
    // si on est en train de déplacer la fenêtre, ce n'est pas un câlin
    setTimeout(() => { if (typeof aDeplace !== 'undefined' && aDeplace) return; caresser(); }, 180);
  });
  function caresser() {
    if (!chibi) return;
    const t = Date.now();
    clics = clics.filter((c) => t - c < 1500);
    clics.push(t);
    derniereAction = t;
    const n = clics.length;
    nomPoke = n === 1 ? 'tape_coeur' : n === 2 ? 'tape_gigote' : n === 3 ? 'tape_tire' : 'tape_etourdie';
    etatPortrait = 'caresse';
    majPortrait();
    portrait.animate([{ transform: 'scale(1,1)' }, { transform: 'scale(1.06,0.94)' }, { transform: 'scale(1,1)' }], { duration: 160 });
    clearTimeout(finPoke);
    finPoke = setTimeout(() => { if (etatPortrait === 'caresse') { etatPortrait = 'repos'; majPortrait(); } }, 2200);
  }

  // ===== Le secret : la compression =====
  let enCours = false;
  async function basculer() {
    if (enCours) return;
    enCours = true;
    const a = portrait.animate([
      { transform: 'scale(1,1)', filter: 'brightness(1)' },
      { transform: 'scale(1.5,0.04)', filter: 'brightness(3)', offset: 0.45 },
      { transform: 'scale(1,1)', filter: 'brightness(1)' }
    ], { duration: 560, easing: 'ease-in-out' });
    setTimeout(() => {
      chibi = !chibi;
      try { localStorage.setItem('capriChibi', chibi ? '1' : '0'); } catch (e) {}
      document.body.classList.toggle('chibi', chibi);
      if (chibi) { etatPortrait = 'repos'; derniereAction = Date.now(); majPortrait(); }
      else portrait.style.setProperty('--img', "url('" + IMAGES[imageActuelle] + "')");
      appliquer();
    }, 250);
    try { await a.finished; } catch (e) {}
    try {
      await typeInto(addRow('capri'), chibi
        ? 'Compression terminée... mode mini activé ! Écris /chibi pour me remettre en grand.'
        : 'Décompression ! Me revoilà en taille normale.', 22);
    } catch (e) {}
    enCours = false;
  }

  // Secret 1 : 5 clics rapides sur le nom « CAPRI »
  const nomCapri = capriBox.querySelector('.nom');
  let secret = [];
  if (nomCapri) {
    nomCapri.addEventListener('pointerdown', (e) => {
      if (e.button !== 0) return;
      const t = Date.now();
      secret = secret.filter((c) => t - c < 2500);
      secret.push(t);
      if (secret.length >= SECRET_CLICS) { secret = []; basculer(); }
    });
  }

  // Secret 2 : écrire /chibi dans le chat
  function intercepter(e) {
    if (input.value.trim().toLowerCase() !== SECRET_TEXTE) return;
    e.stopImmediatePropagation();
    e.preventDefault();
    input.value = '';
    basculer();
  }
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') intercepter(e); }, true);
  document.getElementById('send').addEventListener('click', intercepter, true);

  // ===== Au démarrage : on retrouve le mode choisi la dernière fois =====
  if (chibi) {
    document.body.classList.add('chibi');
    majPortrait();
    appliquer();
  }
})();
